//
//  Calculator.h
//  SparcTest
//
//  Created by Mac Mini on 8/24/13.
//  Copyright (c) 2013 FourEyedDev. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Calculator : NSObject {
    
}

-(float)lengthForNumberOfSteps:(int)steps forMale:(BOOL)isMale withShoeSize:(float)shoeSize;

@end
