//
//  PaintProjectPricesViewController.h
//  handy
//
//  Created by Marvin on 8/24/13.
//  Copyright (c) 2013 Four Eyed Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaintProjectPricesViewController : UIViewController

@property (nonatomic, strong) NSMutableDictionary *projectData;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil dictionary:(NSMutableDictionary *)projectData;

@end
